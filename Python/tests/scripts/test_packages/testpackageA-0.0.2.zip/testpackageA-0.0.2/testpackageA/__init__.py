__version__ = "0.0.2"

from .ClassA import ClassA
