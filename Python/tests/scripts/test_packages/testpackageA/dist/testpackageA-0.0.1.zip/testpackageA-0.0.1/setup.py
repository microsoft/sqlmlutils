from distutils.core import setup

setup(
    name='testpackageA' ,
    packages=['testpackageA'],
    version='0.0.1',
    description='Test package for python package management.',
    author='Microsoft'
)
