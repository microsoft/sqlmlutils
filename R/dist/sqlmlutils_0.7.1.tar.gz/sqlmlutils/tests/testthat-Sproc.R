# Copyright(c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT license.

library(testthat)
library(sqlmlutils)

#test_check("sqlmlutils", filter = "storedProcedure")
