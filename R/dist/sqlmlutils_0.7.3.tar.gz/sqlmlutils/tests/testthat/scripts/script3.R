product <- num1 * num2
out_df <- rbind(in_df, product)
